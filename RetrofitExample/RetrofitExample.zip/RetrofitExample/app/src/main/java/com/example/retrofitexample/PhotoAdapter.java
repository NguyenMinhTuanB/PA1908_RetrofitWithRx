package com.example.retrofitexample;

public class PhotoAdapter {
}
